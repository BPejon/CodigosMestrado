import openai
from pypdf import PdfReader



# creating a pdf reader object 
# reader = PdfReader('interactiveMachineLearningFramework.pdf') 
  
def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    textConverted = '----------------'
    for pageNum in range(len(reader.pages)):
        page = reader.pages[pageNum]
        textConverted += page.extract_text() + "\n --------------------------------\n"

    return textConverted

def sendPDFToChatGPT(pdf):
    openai.api_key = "YOURAPIKEY"
    answer = ''

    answer = openai.ChatCompletion.create(
        model = "gpt-3.5-turbo",
        messages=[
            {"role": "user", "content": pdf},
            {"role": "user", "content": "Retrive from this pdf every quimical or physical elemental on the text."}
            # {"role": "user", "content": "I want a summary of this pdf please within 3 paragraphs."},
            # {"role": "user", "content": "Retrive from the text the future works propose on this study.s"}
        ]
    )


    return answer.choices[0].message


pdfConverted = extract_text_from_pdf('physicsPdf.pdf')
print(pdfConverted)

answer = sendPDFToChatGPT(pdfConverted)
print("ChatGPT Answer: ", answer)