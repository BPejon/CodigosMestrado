from openai import OpenAI
from pypdf import PdfReader

client = OpenAI(
    api_key="YOURAPIKEY"
)

def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    text_reader = "------------------"
    for pageNum in range(len(reader.pages)):
        page = reader.pages[pageNum]
        text_reader += page.extract_text() + "\n -----------------------"

    return text_reader 

def extract_first_page(pdf_path):
    reader = PdfReader(pdf_path)
    first_page = reader.pages[0]
    return first_page.extract_text()

# def create_abstract_image(pdf):
#     response = client.images.generate(
#     model="dall-e-3",
#     prompt="Create a image that summary the main idea of the text bellow: " + 
#     "4f-4f absorption strength o Eu3+ in La2Zr3(MoO4)9 compared to other Eu3+activated luminescent materials " +
#     "ChemistryThis study deals with the optical and luminescent properties of a double molybdate containing rare earth elements, specifically focusing on La2Zr3(MoO4)9:Eu3+ and comparing it with the widely used Y2O3:Eu3+, (Y,Gd)BO3:Eu3+ and YVO4:Eu3+ as well as Y2O2S:Eu3+ and Y(P,V)O4:Eu3+ phosphors. It utilizes Kubelka Munk Theory to estimate the absorption strengths o these materials. Higher absorption coecients indicate greater eciency in absorbing light, leading to more intense and brighter luminescence. This investigation aims to assess La 2Z-r3(MoO4)9:Eu3+ as a promising luminescent material or optoelectronics and solid state lighting by comparing its absorbance properties.",
#     size="1024x1024",
#     quality="standard",
#     n=1,
#     )

#     return response

def create_abstract_image(text):
    response = client.images.generate(
    model="dall-e-3",
    prompt="Create a graphical abstract for the scientific paper abstract: " + text,
    size="1024x1024",
    quality="standard",
    n=1,
    )

    return response

#pdf_converted = extract_first_page('physicsPdf.pdf')
text = """ Machine learning (ML) is believed to be an effective and ef-
ficient tool to build reliable prediction model or extract use-
ful structure from an avalanche of data. However, ML is also
criticized by its difficulty in interpretation and complicated
parameter tuning. In contrast, visualization is able to well or-
ganize and visually encode the entangled information in data
and guild audiences to simpler perceptual inferences and an-
alytic thinking. But large scale and high dimensional data
will usually lead to the failure of many visualization meth-
ods. In this paper, we close a loop between ML and visual-
ization via interaction between ML algorithm and users, so
machine intelligence and human intelligence can cooperate
and improve each other in a mutually rewarding way. In par-
ticular, we propose ”transparent boosting tree (TBT)”, which
visualizes both the model structure and prediction statistics
of each step in the learning process of gradient boosting tree
to user, and involves user’s feedback operations to trees into
the learning process. In TBT, ML is in charge of updating
weights in learning model and filtering information shown
to user from the big data, while visualization is in charge of
providing a visual understanding of ML model to facilitate
user exploration. It combines the advantages of both ML in
big data statistics and human in decision making based on
domain knowledge. We develop a user friendly interface for
this novel learning method, and apply it to two datasets col-
lected from real applications. Our study shows that making
ML transparent by using interactive visualization can signif-
icantly improve the exploration of ML algorithms, give rise
to novel insights of ML models, and integrates both machine
and human intelligence."""
abstract_image = create_abstract_image(text)


image_url = abstract_image.data[0].url

print(image_url)




