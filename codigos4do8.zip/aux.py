from openai import OpenAI
from pypdf import PdfReader
import tiktoken

# Configuração do cliente OpenAI
client = OpenAI(api_key="sua_chave_de_api")

gpt_model = 'gpt-3.5-turbo'
MAX_TOKENS = 4096  # Limite de tokens da API GPT-3.5-turbo

# Mensagens iniciais
messages_array = [
    {"role": "system", "content": "You are a phd professor focused on Langmuir monolayers and Langmuir-Blodgett films."},
    {"role": "user", "content": "Write a structured review paper on Langmuir monolayers and Langmuir-Blodgett films. Use scientific language to write this paper."},
    {"role": "user", "content": "You need to answer these 6 questions within its topics."},
    {"role": "user", "content": "1. What are the most relevant topics in Langmuir monolayers and Langmuir-Blodgett (LB) films?"},
    {"role": "user", "content": "2. Which are the most relevant materials used in these films?"},
    {"role": "user", "content": "3. Which are the most important potential applications of these films?"},
    {"role": "user", "content": "4. Which are the trends in this area?"},
    {"role": "user", "content": "5. Which are the most critical challenges in this area?"},
    {"role": "user", "content": "6. How do Langmuir monolayers and LB films relate to other types of films?"},
    {"role": "user", "content": "You will receive 5 pdfs to support the answers to the questions. You do not need to use all of the pdfs to give an answer."}
]

def calculate_array_tokens(gpt_model, messages_array):
    encoding = tiktoken.encoding_for_model(gpt_model)
    input_tokens = sum([len(encoding.encode(message['content'])) for message in messages_array])
    return input_tokens

def calculate_pdf_tokens(gpt_model, pdf_array):
    encoding = tiktoken.encoding_for_model(gpt_model)
    pdf_tokens = sum(len(encoding.encode(pdf)) for pdf in pdf_array)
    return pdf_tokens

def calculate_string_tokens(gpt_model, message_string):
    encoding = tiktoken.encoding_for_model(gpt_model)
    string_token = len(encoding.encode(message_string))
    return string_token

def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    text_converted = ''
    for page_num in range(len(reader.pages)):
        page = reader.pages[page_num]
        text_converted += page.extract_text() + "\n"
    return text_converted

def split_text(text, encoding, max_tokens):
    tokens = encoding.encode(text)
    split_texts = []
    while len(tokens) > max_tokens:
        split_point = max_tokens
        split_texts.append(encoding.decode(tokens[:split_point]))
        tokens = tokens[split_point:]
    split_texts.append(encoding.decode(tokens))
    return split_texts

def send_messages_to_chatgpt(client, gpt_model, messages):
    response = client.chat.completions.create(
        model=gpt_model,
        messages=messages
    )
    return response.choices[0].message.content

def send_pdf_to_chatgpt(gpt_model, messages, pdf_texts):
    encoding = tiktoken.encoding_for_model(gpt_model)
    max_tokens_per_message = MAX_TOKENS - calculate_array_tokens(gpt_model, messages)
    split_pdf_texts = []
    for pdf_text in pdf_texts:
        split_pdf_texts.extend(split_text(pdf_text, encoding, max_tokens_per_message))
    
    responses = []
    for pdf_text_part in split_pdf_texts:
        temp_messages = messages + [{"role": "user", "content": pdf_text_part}]
        responses.append(send_messages_to_chatgpt(client, gpt_model, temp_messages))
    
    return "\n".join(responses)

# Extração de texto dos PDFs
pdf_array = []
pdf_num = 1
for pdf in range(1):
    pdf_converted = extract_text_from_pdf(f'pdfs/{pdf_num}.pdf')
    pdf_array.append(pdf_converted)
    pdf_num += 1

# Cálculo de tokens de entrada
input_tokens = calculate_array_tokens(gpt_model, messages_array)
pdf_tokens = calculate_pdf_tokens(gpt_model, pdf_array)
total_tokens = input_tokens + pdf_tokens
print(f"Numero de tokens na entrada: {total_tokens} (in+pdf {input_tokens}+{pdf_tokens})")

# Envio das mensagens e PDFs ao modelo
answer = send_pdf_to_chatgpt(gpt_model, messages_array, pdf_array)

# Salvar a resposta em um arquivo
with open('saida3.txt', 'w') as arq:
    arq.write(answer)

# Cálculo de tokens de saída
output_tokens = calculate_string_tokens(gpt_model, answer)
print(f"Numero de tokens na saída: {output_tokens}")
