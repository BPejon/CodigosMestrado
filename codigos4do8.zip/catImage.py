from openai import OpenAI
client = OpenAI(
    api_key="YOURAPIKEY"
)


response = client.images.generate(
  model="dall-e-3",
  prompt="a white siamese cat",
  size="1024x1024",
  quality="standard",
  n=1,
)

answer = response
image_url = response.data[0].url

print(answer)
print(image_url)

#A well-detailed depiction of a Siamese cat. Its fur is painted in white color, with blue almond-shaped eyes and a lean elegant body. The cat is seen sitting gracefully, its sleek tail curled around its paws. The surroundings are minimalistic, to make the feline stand out. The color contrasts and the fine fur details should be given special attention.

