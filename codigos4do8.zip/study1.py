from openai import OpenAI
import tiktoken

client = OpenAI(
    api_key="YOURAPIKEY"
)




messages_array = [
        {"role": "system", "content": "You are a phd professor focused on Langmuir monolayers and Langmuir-Blodgett films."},
        {"role": "user", "content": "Write a structured review paper with minimun of 5000 caracters on Langmuir monolayers and Langmuir-Blodgett films. Use scientific language to write this paper. This paper needs to answer the questions bellow:"},
        {"role": "user", "content": "1. What are the most relevant topics in Langmuir monolayers and Langmuir-Blodgett (LB) films?"},
        {"role": "user", "content": "2. Which are the most relevant materials used in these films?"},
        {"role": "user", "content": "3. which are the most important potential applications of these films?"},
        {"role": "user", "content": "4. Which are the trends in this area?"},
        {"role": "user", "content": "5. Which are the most critical challenges in this area?"},
        {"role": "user", "content": "6. How Langmuir monolayers and LB films relate to other types of films?"},

    ] 

def callGpt(message):
    completion = client.chat.completions.create(
    model = "gpt-3.5-turbo",
    messages= message
        
    )

    return completion.choices[0].message.content


encoding = tiktoken.encoding_for_model("gpt-3.5-turbo")

input_tokens = sum([len(encoding.encode(message['content'])) for message in messages_array])
print(f"Numero de tokens na entrada: {input_tokens}")

output_content = callGpt(messages_array)
output_tokens = len(encoding.encode(output_content))
print(f"Total tokens na saída: {output_tokens}")

# i = 0
# total_tokens = 0
# for message in messages_array:
#     output_content = callGpt(message)
#     output_tokens = len(encoding.encode(output_content))
#     print(f" Messagem {i} tem {output_tokens} tokens")
#     total_tokens += output_tokens 
#     ++i

#print(f"Numero de tokens na saída: {total_tokens}")

with open('saida1.txt', 'w') as arq:
    arq.write(output_content)