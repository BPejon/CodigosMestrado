import openai

openai.api_key = "YOURAPIKEY"

completion= openai.ChatCompletion.create(
    model = "gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "Você é um poeta muito habilidoso dos anos 90"},
        {"role": "user", "content": "Faça um poema sobre a vida de estudar na universidade"}
    ]
)

print(completion.choices[0].message)