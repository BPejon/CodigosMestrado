#Systematic review with one pdf with embedding

from openai import OpenAI
from pypdf import PdfReader
import tiktoken

client = OpenAI(
    api_key="YOURAPIKEY"
)

gpt_model ='gpt-3.5-turbo',
embedding_model = "text-embedding-3-small"
messages_array = [
        {"role": "system", "content": "You are a phd professor focused on Langmuir monolayers and Langmuir-Blodgett films."},
        {"role": "user", "content": "Write a structured review paper on Langmuir monolayers and Langmuir-Blodgett films. Use scientific language to write this paper."},
        {"role": "user", "content": "YOu need to answer this 6 questions within its topics."},
        {"role": "user", "content": "1. What are the most relevant topics in Langmuir monolayers and Langmuir-Blodgett (LB) films?"},
        {"role": "user", "content": "2. Which are the most relevant materials used in these films?"},
        {"role": "user", "content": "3. which are the most important potential applications of these films?"},
        {"role": "user", "content": "4. Which are the trends in this area?"},
        {"role": "user", "content": "5. Which are the most critical challenges in this area?"},
        {"role": "user", "content": "6. How Langmuir monolayers and LB films relate to other types of films?"},
        {"role": "user", "content": "You will receive a pdf to support the answers to the questions"}
    ] 

def calculate_array_tokens(gpt_model,messages_array):
    encoding = tiktoken.encoding_for_model(gpt_model)
    input_tokens = sum([len(encoding.encode(message['content'])) for message in messages_array])
    return input_tokens
    
def calculate_string_tokens(gpt_model,message_string):
    encoding = tiktoken.encoding_for_model(gpt_model)
    string_token = len(encoding.encode(message_string))
    return string_token
  
def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    textConverted = '----------------'
    for pageNum in range(len(reader.pages)):
        page = reader.pages[pageNum]
        textConverted += page.extract_text() + "\n --------------------------------\n"

    return textConverted

def sendPDFToChatGPT(gpt_model,message, pdf):
    message.append({"role": "user","content": pdf},)
    completion = client.chat.completions.create(
        model= gpt_model,
        messages = message
    )

    return completion.choices[0].message.content


pdfConverted = extract_text_from_pdf('pdfs/1.pdf')
gpt_model ='gpt-3.5-turbo'
input_tokens = calculate_array_tokens(gpt_model,messages_array)
pdf_tokens = calculate_string_tokens(gpt_model,pdfConverted)
total_tokens = input_tokens + pdf_tokens
print(f"Numero de tokens na entrada: {total_tokens} (in+pdf {input_tokens}+{pdf_tokens})")


answer = sendPDFToChatGPT(gpt_model, messages_array, pdfConverted)
with open('saida2.txt', 'w') as arq:
    arq.write(answer)

output_tokens = calculate_string_tokens(gpt_model,answer)
print(f"Numero de tokens na saida: {output_tokens}")

