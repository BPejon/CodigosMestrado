#With 8 pdfs
#Systematic review with one pdf 

from openai import OpenAI
from pypdf import PdfReader
import tiktoken

client = OpenAI(
    api_key="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"
)

MAX_TOKENS= 16370
gpt_model ='gpt-3.5-turbo'
messages_array = [
        {"role": "system", "content": "You are a phd professor focused on Langmuir monolayers and Langmuir-Blodgett films."},
        {"role": "user", "content": "Write a structured review paper on Langmuir monolayers and Langmuir-Blodgett films. Use scientific language to write this paper."},
        {"role": "user", "content": "You need to answer this 6 questions within its topics."},
        {"role": "user", "content": "1. What are the most relevant topics in Langmuir monolayers and Langmuir-Blodgett (LB) films?"},
        {"role": "user", "content": "2. Which are the most relevant materials used in these films?"},
        {"role": "user", "content": "3. which are the most important potential applications of these films?"},
        {"role": "user", "content": "4. Which are the trends in this area?"},
        {"role": "user", "content": "5. Which are the most critical challenges in this area?"},
        {"role": "user", "content": "6. How Langmuir monolayers and LB films relate to other types of films?"},
        {"role": "user", "content": "You will receive 5 pdf to support the answers to the questions. You do not need to use all of the pdf to give an answer."}
    ] 

def calculate_array_tokens(gpt_model,messages_array):
    encoding = tiktoken.encoding_for_model(gpt_model)
    input_tokens = sum([len(encoding.encode(message['content'])) for message in messages_array])
    return input_tokens
    
def calculate_pdf_tokens(gpt_model, pdf_array):
    encoding = tiktoken.encoding_for_model(gpt_model)
    pdf_tokens = sum(len(encoding.encode(pdf)) for pdf in pdf_array)
    return pdf_tokens

def calculate_string_tokens(gpt_model,message_string):
    encoding = tiktoken.encoding_for_model(gpt_model)
    string_token = len(encoding.encode(message_string))
    return string_token
  
def extract_text_from_pdf(pdf_path):
    reader = PdfReader(pdf_path)
    textConverted = '----------------'
    for pageNum in range(len(reader.pages)):
        page = reader.pages[pageNum]
        textConverted += page.extract_text() + "\n --------------------------------\n"

    return textConverted


def split_text(pdf, encoding):
    tokens = encoding.encode(pdf)
    split_texts = []
    split_point = MAX_TOKENS
    while len(tokens) > MAX_TOKENS:
        token_chunk = tokens[:split_point]
        text_chunk = encoding.decode(token_chunk)
        split_texts.append(text_chunk)        
        tokens = tokens[split_point:]

    remaining_text = encoding.decode(tokens)
    split_texts.append(remaining_text)

    return split_texts

def send_message_chatgpt(gpt_model,message_text):
    completion = client.chat.completions.create(
        model= gpt_model,
        messages = message_text
    )
    return completion.choices[0].message.content

def send_pdf_to_chatGPT(gpt_model, pdf_text):
    message_text = [{"role":"user","content":pdf_text}]
    completion = client.chat.completions.create(
        model= gpt_model,
        messages = message_text
    )
    return completion.choices[0].message.content

def talk_to_GPT(gpt_model,message, pdf):
    encoding = tiktoken.encoding_for_model(gpt_model)
    split_pdf_texts= []

    for pdf_text in pdf:
        text_divided = split_text(pdf_text, encoding)
        split_pdf_texts.extend(text_divided)

    responses =[]
    responses.append(send_message_chatgpt(gpt_model, message))
    for pdf_text_part in split_pdf_texts:
        responses.append(send_pdf_to_chatGPT(gpt_model,pdf_text_part))
        
    return "\n".join(responses)

pdf_array= []
pdf_num = 1
for pdf in range(4):
    pdfConverted = extract_text_from_pdf(f'pdfs/{pdf_num}.pdf')
    pdf_array.append(pdfConverted)
    pdf_num += 1
    
gpt_model ='gpt-3.5-turbo'
input_tokens = calculate_array_tokens(gpt_model,messages_array)
pdf_tokens = calculate_pdf_tokens(gpt_model,pdf_array)
total_tokens = input_tokens + pdf_tokens
print(f"Numero de tokens na entrada: {total_tokens} (in+pdf {input_tokens}+{pdf_tokens})")


answer = talk_to_GPT(gpt_model, messages_array, pdf_array)
with open('saida3.txt', 'w') as arq:
    arq.write(answer)

output_tokens = calculate_string_tokens(gpt_model,answer)
print(f"Numero de tokens na saida: {output_tokens}")

