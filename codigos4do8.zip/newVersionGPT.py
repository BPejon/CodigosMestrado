from openai import OpenAI

client = OpenAI(
    api_key="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"
)

stream = client.chat.completions.create(
        model = "gpt-3.5-turbo",
        messages=[
        {"role": "system", "content": "Você é um poeta muito habilidoso dos anos 90"},
        {"role": "user", "content": "Faça um poema sobre a vida de estudar na universidade"}
        ],
        stream=True
)

for chunk in stream:
    if chunk.choices[0].delta.content is not None:
        print(chunk.choices[0].delta.content, end="")