from openai import OpenAI

client = OpenAI(
    api_key="YOURAPIKEY"
)

#Falar pra ele q ele os artigos podem estar errados por conta das datas, e para priorizar artigos mais recentes

completion = client.chat.completions.create(
    model = "gpt-3.5-turbo",
    messages=[
        {"role": "system", "content": "You are a phd professor focused on Langmuir monolayers and Langmuir-Blodgett films."},
        {"role": "user", "content": "Produce a structure review paper on Langmuir monolayers and Langmuir-Blodgett films. Use scientific language to write this paper."}
    ]   
)

with open('saida.txt', 'w') as arq:
    arq.write(completion.choices[0].message.content)